const $=id=>document.getElementById(id);
const KEY='smartTailorDataV1';
let db=JSON.parse(localStorage.getItem(KEY)||'{"customers":[],"orders":[]}');
const fields=['shirtLength','chest','shoulder','sleeve','collar','cuff','hem','trouserLength','waist','hip','bottom'];
const labels={shirtLength:'قمیض لمبائی',chest:'چھاتی',shoulder:'کندھا',sleeve:'آستین',collar:'کالر',cuff:'کف',hem:'دامن / گھیر',trouserLength:'شلوار لمبائی',waist:'کمر',hip:'ہپ',bottom:'پائنچہ'};
function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function val(x){return $(x).value.trim()}
function show(tab){document.querySelectorAll('main section').forEach(s=>s.classList.add('hidden'));$(tab).classList.remove('hidden');document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));if(tab==='addOrder')fillCustomers()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>show(b.dataset.tab));
function clearCustomer(){['editCustomerId','cName','cPhone','cAddress','measureNote',...fields].forEach(x=>$(x).value='');$('customerFormTitle').textContent='نیا گاہک شامل کریں'}
$('saveCustomer').onclick=()=>{
 if(!val('cName'))return alert('گاہک کا نام درج کریں');
 const m={};fields.forEach(f=>m[f]=val(f));
 const cid=val('editCustomerId');
 const c={id:cid||id(),name:val('cName'),phone:val('cPhone'),address:val('cAddress'),measurements:m,note:val('measureNote'),updated:new Date().toISOString()};
 if(cid)db.customers=db.customers.map(x=>x.id===cid?c:x);else db.customers.unshift(c);
 clearCustomer();save();show('customers');alert('گاہک کا ریکارڈ محفوظ ہوگیا');
};
function editCustomer(cid){const c=db.customers.find(x=>x.id===cid);if(!c)return;show('addCustomer');$('customerFormTitle').textContent='گاہک کا ریکارڈ تبدیل کریں';$('editCustomerId').value=c.id;$('cName').value=c.name;$('cPhone').value=c.phone;$('cAddress').value=c.address;$('measureNote').value=c.note||'';fields.forEach(f=>$(f).value=c.measurements?.[f]||'')}
function customerCard(c){let filled=fields.filter(f=>c.measurements?.[f]).length;return `<div class="listitem"><div class="row"><b>${esc(c.name)}</b><button class="action" onclick="editCustomer('${c.id}')">ناپ / ترمیم</button></div><div class="muted">${esc(c.phone||'موبائل درج نہیں')} • ${filled} ناپ درج</div><div class="row" style="margin-top:8px"><button class="action" onclick="newOrderFor('${c.id}')">نیا آرڈر</button><button class="action danger" onclick="deleteCustomer('${c.id}')">حذف</button></div></div>`}
function deleteCustomer(cid){if(confirm('کیا یہ گاہک اور اس کے متعلقہ آرڈرز حذف کریں؟')){db.customers=db.customers.filter(c=>c.id!==cid);db.orders=db.orders.filter(o=>o.customerId!==cid);save()}}
function newOrderFor(cid){show('addOrder');fillCustomers();$('orderCustomer').value=cid}
function fillCustomers(){$('orderCustomer').innerHTML=db.customers.map(c=>`<option value="${c.id}">${esc(c.name)} — ${esc(c.phone)}</option>`).join('');if(!db.customers.length)$('orderCustomer').innerHTML='<option value="">پہلے گاہک شامل کریں</option>'}
$('saveOrder').onclick=()=>{if(!val('orderCustomer'))return alert('پہلے گاہک شامل کریں');let total=Number(val('total')||0),advance=Number(val('advance')||0);if(advance>total)return alert('ایڈوانس کل رقم سے زیادہ نہیں ہوسکتا');db.orders.unshift({id:id(),customerId:val('orderCustomer'),date:val('orderDate'),delivery:val('deliveryDate'),quantity:Number(val('quantity')||1),total,advance,status:val('status'),note:val('orderNote')});['deliveryDate','total','orderNote'].forEach(x=>$(x).value='');$('advance').value='0';save();show('orders');alert('آرڈر محفوظ ہوگیا')};
function orderCard(o){let c=db.customers.find(x=>x.id===o.customerId),due=o.total-o.advance;return `<div class="listitem"><div class="row"><b>${esc(c?.name||'نامعلوم گاہک')}</b><span class="pill">${esc(o.status)}</span></div><div class="muted">ڈیلیوری: ${esc(o.delivery||'درج نہیں')} • تعداد: ${o.quantity}</div><div style="margin:7px 0">کل: Rs ${o.total} | ایڈوانس: Rs ${o.advance} | <b>باقی: Rs ${due}</b></div><div class="row"><button class="action" onclick="cycleStatus('${o.id}')">حالت تبدیل کریں</button><button class="action danger" onclick="deleteOrder('${o.id}')">حذف</button></div></div>`}
function cycleStatus(oid){let o=db.orders.find(x=>x.id===oid),s=['موصول','سلائی جاری','تیار','حوالہ کر دیا'];o.status=s[(s.indexOf(o.status)+1)%s.length];save()}
function deleteOrder(oid){if(confirm('یہ آرڈر حذف کریں؟')){db.orders=db.orders.filter(o=>o.id!==oid);save()}}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){ $('customerCount').textContent=db.customers.length;$('orderCount').textContent=db.orders.length;$('dueCount').textContent=db.orders.filter(o=>o.total>o.advance).length;
 let q=val('search').toLowerCase();$('customerList').innerHTML=db.customers.filter(c=>(c.name+' '+c.phone).toLowerCase().includes(q)).map(customerCard).join('')||'<p class="muted">ابھی کوئی گاہک موجود نہیں۔ نیا گاہک شامل کریں۔</p>';
 $('orderList').innerHTML=db.orders.map(orderCard).join('')||'<p class="muted">ابھی کوئی آرڈر موجود نہیں۔</p>';fillCustomers()}
$('search').oninput=render;
$('exportBtn').onclick=()=>{let blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='smart-tailor-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(a.href)};
$('importFile').onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let d=JSON.parse(await f.text());if(!Array.isArray(d.customers)||!Array.isArray(d.orders))throw Error();if(confirm('موجودہ ڈیٹا کی جگہ بیک اَپ والا ڈیٹا آئے گا۔ جاری رکھیں؟')){db=d;save();alert('بیک اَپ بحال ہوگیا')}}catch{alert('یہ درست بیک اَپ فائل نہیں ہے')}e.target.value=''};
$('orderDate').value=new Date().toISOString().slice(0,10);render();
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));